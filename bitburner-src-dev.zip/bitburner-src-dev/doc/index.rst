.. meta::
   :http-equiv=Refresh: 0; url='https://github.com/bitburner-official/bitburner-src/blob/stable/src/Documentation/doc/index.md'

This link is outdated as documentation for Bitburner has been migrated to an in-game menu, this page should have redirected you to the new location.
You can also click `here to go to the game's documentation <https://github.com/bitburner-official/bitburner-src/blob/stable/src/Documentation/doc/index.md/>`_.
