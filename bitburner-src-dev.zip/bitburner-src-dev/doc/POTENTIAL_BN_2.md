A game of risk from the point of view of a politician.

You allocate resources on a world map, trying to win elections.
