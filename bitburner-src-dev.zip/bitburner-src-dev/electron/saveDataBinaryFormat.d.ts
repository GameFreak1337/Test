export declare const isBinaryFormat: (saveData: string | Uint8Array) => boolean;
