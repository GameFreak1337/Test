Don't be an ass.
